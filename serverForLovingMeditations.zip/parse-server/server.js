'use strict';

// [START app]
var express = require('express');
var nconf = require('nconf');
var ParseServer = require('parse-server').ParseServer;
var path = require('path');
var SimpleSendGridAdapter = require('parse-server-sendgrid-adapter');
var bodyParser = require('body-parser');
var request = require("request");

nconf.argv().env().file({ file: 'config.json' });

var app = express();

var parseServer = new ParseServer({
  databaseURI: nconf.get('DATABASE_URI') || 'mongodb://localhost:27017/dev',
  cloud: nconf.get('CLOUD_PATH') || path.join(__dirname, '/cloud/main.js'),
  appId: nconf.get('APP_ID'),
  masterKey: nconf.get('MASTER_KEY'),
  fileKey: nconf.get('FILE_KEY'),
  serverURL: nconf.get('SERVER_URL'),
  appName: 'Loving Meditations App',
  verifyUserEmails: true,
  preventLoginWithUnverifiedEmail: true,
  publicServerURL: 'https://lmserver-1281.appspot.com/parse',
  emailAdapter: SimpleSendGridAdapter({
    apiKey: nconf.get('SENDGRID_API_KEY'),
    domain: nconf.get('DOMAIN'),
    fromAddress: nconf.get('FROM_ADDRESS')
  })
});

app.use(function (req, res, next) {
    // Websites you wish to allow to connect
    var allowedOrigins = ['http://matthewlindsaypayne.github.io', 'http://lovingmeditations.com'];
    var origin = req.headers.origin;
    if(allowedOrigins.indexOf(origin) > -1){
       res.setHeader('Access-Control-Allow-Origin', origin);
    }

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});

app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

// Mount the Parse API server middleware to /parse
app.use(process.env.PARSE_MOUNT_PATH || '/parse', parseServer);

app.get('/', function (req, res) {
  res.status(200).send('Working, Working, 31313.');
});

app.post('/mail', function(req, res) {
    var helper = require('sendgrid').mail;
    
    var from_email = new helper.Email(req.body.fromEmail);
    var to_email = new helper.Email(req.body.toEmail);
    var subject = req.body.subject;
    var content = new helper.Content("text/plain", req.body.content);
    var mail = new helper.Mail(from_email, subject, to_email, content);

    var sg = require('sendgrid').SendGrid(nconf.get('SENDGRID_API_KEY'));
    var requestBody = mail.toJSON();
    var request = sg.emptyRequest();
    request.method = 'POST';
    request.path = '/v3/mail/send';
    request.body = requestBody;
    sg.API(request, function (response) {
        console.log(response.statusCode)
        console.log(response.body)
        console.log(response.headers)
    });
});

app.post('/invite/:email/:name', function(req, res) {
    var helper = require('sendgrid').mail;
    
    var toEmail = req.params.email;
    var name = req.params.name;
    
    var from_email = new helper.Email(nconf.get('FROM_ADDRESS'));
    var to_email = new helper.Email(toEmail);
    var subject = 'You\'ve been invited to Loving Meditations!';
    var content = new helper.Content("text/plain", 'Hey, ' + name +', you\' been invited to try out the Loving Meditations app!  Go to http://lovingmeditations.com/app/index.html to sign up!');
    var mail = new helper.Mail(from_email, subject, to_email, content);

    var sg = require('sendgrid').SendGrid(nconf.get('SENDGRID_API_KEY'));
    var requestBody = mail.toJSON();
    var request = sg.emptyRequest();
    request.method = 'POST';
    request.path = '/v3/mail/send';
    request.body = requestBody;
    sg.API(request, function (response) {
        res.status(response.statusCode).send(response.body);
    });
});

app.post('/', function(req, res) {
    
});

app.get('/subscribeAnnually/:stripeToken/:email', function(req, res) {
    var stripeToken = req.params.stripeToken;
    var email = req.params.email;
    request("https://lm-stripe-mirror.herokuapp.com/subscribeAnnually/" + stripeToken + "/" + email, function(error, response, body) {
        res.json(body);
    });
});

app.get('/subscribeMonthly/:stripeToken/:email', function(req, res) {
    var stripeToken = req.params.stripeToken;
    var email = req.params.email;
    request("https://lm-stripe-mirror.herokuapp.com/subscribeMonthly/" + stripeToken + "/" + email, function(error, response, body) {
        res.json(body);
    });
});

app.get('/customers/:customer', function(req, res) {
    var customer = req.params.customer;
    request("https://lm-stripe-mirror.herokuapp.com/customers/" + customer, function(error, response, body) {
        res.json(body);
    });
});

app.get('/cancel/:customer/:subscription', function(req, res) {
    var customer = req.params.customer;
    var subscription = req.params.subscription;
    request("https://lm-stripe-mirror.herokuapp.com/cancel/" + customer + "/" + subscription, function(error, response, body) {
        res.json(body);
    });
});

var server = app.listen(process.env.PORT || 8080, function () {
  console.log('App listening on port %s', server.address().port);
  console.log('Press Ctrl+C to quit.');
});